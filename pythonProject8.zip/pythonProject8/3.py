def get_elem(d, k):
    if k in d:
        return d[k]
    else:
        return None


# Пример
d = {'a': 1, 'b': None, 'c': [1, 2]}
k = 'a'
result = get_elem(d, k)
print(result)

k = 'd'
result = get_elem(d, k)
print(result)
