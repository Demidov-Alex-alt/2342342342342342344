def de_none(lst):
    return [x for x in lst if x is not None]


# Пример

lst = [None, None, 1, [], (), {}, None]
result = de_none(lst)
print(result)
