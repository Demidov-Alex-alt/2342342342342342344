def list_insert(ref_list, start, num, rep):
    if len(ref_list) < start:
        return -1
    return ref_list[:start] + [num] * rep + ref_list[start:]


# пример 1
ref_list = [0, 1, 2, 3, 4, 5]
start = 4
num = 40
rep = 2
print(list_insert(ref_list, start, num, rep))

# пример 2
ref_list = [0, 1]
start = 2
num = 20
rep = 3
print(list_insert(ref_list, start, num, rep))

# пример 3
ref_list = [0, 1]
start = 5
num = 20
rep = 3
print(list_insert(ref_list, start, num, rep))

# пример 4
ref_list = []
start = 0
num = 0
rep = 4
print(list_insert(ref_list, start, num, rep))
